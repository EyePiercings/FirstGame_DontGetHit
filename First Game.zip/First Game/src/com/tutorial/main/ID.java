package com.tutorial.main;

public enum ID {
	
	Player(),
	BasicEnemy(),
	FastEnemy(),
	SmartEnemy(),
	HardEnemy(),
	EnemyBoss(),
	MenuParticle(),
	Trail();

}
